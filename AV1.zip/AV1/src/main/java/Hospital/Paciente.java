package Hospital;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Paciente {
    private int id;
    private String nome;
    private String rg;
    private String endereco;
    private String telefone;
    private LocalDate dataNascimento;
    private String profissao;
    private List<Exame> exames;

    public Paciente() {

        this.exames = new ArrayList<>();
    }

    public Paciente(int id, String nome, String rg, String endereco, String telefone, LocalDate dataNascimento, String profissao) {

        if (id <= 0) {
            throw new IllegalArgumentException("ID deve ser maior que zero.");
        }

        if (nome == null || nome.isEmpty()) {
            throw new IllegalArgumentException("Nome não pode ser nulo ou vazio.");
        }

        this.id = id;
        this.nome = nome;
        this.rg = rg;
        this.endereco = endereco;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.profissao = profissao;
        this.exames = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public List<Exame> getExames() {
        return exames;
    }

    public void adicionarExame(Exame exame) {
        exames.add(exame);
    }

    public String toString() {
        return "Paciente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", rg='" + rg + '\'' +
                '}';
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Paciente paciente = (Paciente) o;
        return id == paciente.id && Objects.equals(nome, paciente.nome) && Objects.equals(rg, paciente.rg);
    }

    public int hashCode() {
        return Objects.hash(id, nome, rg);
    }
}
