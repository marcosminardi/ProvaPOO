package Hospital;


import java.util.Objects;

public class Exame {
    private int id;
    private String descricao;

    public Exame() {

    }

    public Exame(int id, String descricao) {
        // Validação dos argumentos
        if (id <= 0) {
            throw new IllegalArgumentException("ID deve ser maior que zero.");
        }

        if (descricao == null || descricao.isEmpty()) {
            throw new IllegalArgumentException("Descrição não pode ser nula ou vazia.");
        }

        this.id = id;
        this.descricao = descricao;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }


    public String toString() {
        return "Exame{" +
                "id=" + id +
                ", descricao='" + descricao + '\'' +
                '}';
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Exame exame = (Exame) o;
        return id == exame.id && Objects.equals(descricao, exame.descricao);
    }
    public int hashCode() {
        return Objects.hash(id, descricao);
    }
}
