package Hospital;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        Paciente paciente1 = new Paciente(1, "João", "12345678", "Rua A", "123-4567", LocalDate.of(1980, 5, 10), "Médico");
        Paciente paciente2 = new Paciente(2, "Maria", "87654321", "Rua B", "987-6543", LocalDate.of(1990, 7, 15), "Enfermeira");

        Exame exame1 = new Exame(101, "Hemograma");
        Exame exame2 = new Exame(102, "Raio-X");
        Exame exame3 = new Exame(103, "Ultrassom");


        paciente1.adicionarExame(exame1);
        paciente1.adicionarExame(exame2);

        paciente2.adicionarExame(exame3);

        System.out.println("Informações do Paciente 1: ");
        System.out.println(paciente1);
        System.out.println("Exames do Paciente 1: ");


        System.out.println("\nInformações do Paciente 2: ");
        System.out.println(paciente2);
        System.out.println("Exames do Paciente 2: ");
    }
}
